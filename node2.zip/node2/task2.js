const http =  require('http');

http.createServer();

const ports = 3000;

http.get('/', (req, res) => {
    res.send('Hello World!');
});

http.get('/about', (req, res) => {
    res.send('Welcome to about us page');
});

http.get('/contact', (req, res) => {
    res.send('Welcome to contact us page');
});

http.listen(port, () => {
    console.log(`Server is running on http://localhost:${ports}`);
});